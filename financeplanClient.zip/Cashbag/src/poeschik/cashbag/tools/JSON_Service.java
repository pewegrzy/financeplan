package poeschik.cashbag.tools;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import poeschik.cashbag.messages.Amount;
import poeschik.cashbag.messages.Category;

import com.db4o.ObjectSet;

public class JSON_Service {
	
	/*
	 * parsing class between object and JSON
	 */

	private static final String AMOUNT = "entries";
	

	public static JSONObject getAmounts(ObjectSet<Amount> set) {
		JSONObject o = null;
		try {
			JSONObject rootAmount = new JSONObject();

			JSONArray array = new JSONArray();
			rootAmount.put(AMOUNT, array);
			for (Amount a : set) {
				o = new JSONObject();
				o.put("categoryName", a.getCategory().getName());
				o.put("value", a.getValue());
				o.put("date", a.getDate());
				array.put(o);
			}

			return rootAmount;
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}
	}

	

	public static Category[] getCategories(JSONArray a) {
		Category[] set = new Category[a.length()];

		Category c = null;
		try {
			for (int i = 0; i < a.length(); i++) {
				c = new Category();
				JSONObject category = a.getJSONObject(i);
				c.setIndex(category.getInt("Id"));
				c.setName(category.getString("Category"));
				set[i] = c;
			}

			return set;
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}
	}
}
