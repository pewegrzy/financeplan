package poeschik.cashbag.tools;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import poeschik.cashbag.messages.Amount;
import poeschik.cashbag.messages.Category;
import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import com.db4o.ObjectSet;

public class HttpClient implements Client {

	private static final String POST_URL = "http://www.travel-smarter.de/finance-plan/index.php/getJsonFromRalf";
	private static final String GET_URL = "http://www.travel-smarter.de/finance-plan/index.php/showCategories";
	private static Context context;

	private Handler handler = null;

	public HttpClient(Context ctx, Handler hdl) {
		context = ctx;
		handler = hdl;
	}

	public boolean isConnected() {
		// check internet connection and tell the result
		ConnectivityManager connMgr = (ConnectivityManager) context
				.getSystemService(Activity.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
		if (networkInfo != null && networkInfo.isConnected()) {
			notifyHandler(N_CLIENT_ONLINE);
			return true;
		} else {
			notifyHandler(N_CLIENT_OFFLINE);
			return false;
		}

	}

	public boolean sendMessage(ObjectSet<Amount> data) {

		JSONObject tmp = null;
		// parse the Objects in JSON format
		tmp = JSON_Service.getAmounts(data);

		if (tmp != null) {
			// start the synchronization
			new HttpAsyncTask().execute(POST_URL, tmp.toString());
			return true;
		}
		return false;
	}

	private class HttpAsyncTask extends AsyncTask<String, Void, String> {
		@Override
		protected String doInBackground(String... urls) {
			
			return POST(urls[0], urls[1]);
		}

		// onPostExecute displays the results of the AsyncTask.
		@Override
		protected void onPostExecute(String result) {
			// Toast.makeText(getBaseContext(), "Data Sent!",
			// Toast.LENGTH_LONG).show();
		}
	}

	private String POST(String url, String data) {
		InputStream inputStream = null;
		String result = "";
		notifyHandler(N_CLIENT_PROGRESS);
		try {

			// create HttpClient
			DefaultHttpClient httpclient = new DefaultHttpClient();

			// make POST request to the given URL
			HttpPost httpPost = new HttpPost(url);

			// set json to StringEntity
			StringEntity se = new StringEntity(data);

			// set httpPost Entity
			httpPost.setEntity(se);

			// set some headers to inform server about the type of the content
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");

			// execute POST request to the given URL
			HttpResponse httpResponse = httpclient.execute(httpPost);

			// receive response as inputStream
			inputStream = httpResponse.getEntity().getContent();

			// convert inputstream to string
			if (inputStream != null)
				result = convertInputStreamToString(inputStream);
			else
				result = "Did not work!";

		} catch (Exception e) {
			Log.d("InputStream", e.getLocalizedMessage());
		}

		notifyHandler(DelayHandler.N_DELAY);
		return result;
	}

	private static String convertInputStreamToString(InputStream inputStream)
			throws IOException {
		BufferedReader bufferedReader = new BufferedReader(
				new InputStreamReader(inputStream));
		String line = "";
		String result = "";
		while ((line = bufferedReader.readLine()) != null)
			result += line;

		inputStream.close();
		return result;

	}

	public Category[] receiveCategories() {
		String message = GET();
		JSONArray a;
		try {
			JSONObject o = new JSONObject(message);
			a = o.getJSONArray("categories");
		} catch (JSONException e) {
			e.printStackTrace();
			return null;
		}

		return JSON_Service.getCategories(a);
	}

	private String GET() {
		notifyHandler(N_CLIENT_PROGRESS);
		StringBuilder builder = new StringBuilder();
		DefaultHttpClient client = new DefaultHttpClient();
		HttpGet httpGet = new HttpGet(GET_URL);
		try {
			HttpResponse response = client.execute(httpGet);
			StatusLine statusLine = response.getStatusLine();
			int statusCode = statusLine.getStatusCode();
			if (statusCode == 200) {
				HttpEntity entity = response.getEntity();
				InputStream content = entity.getContent();
				BufferedReader reader = new BufferedReader(
						new InputStreamReader(content));
				String line;
				while ((line = reader.readLine()) != null) {
					builder.append(line);
				}
			} else {
				Log.e(HttpClient.class.toString(), "Failed to download file");
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		notifyHandler(DelayHandler.N_DELAY);
		return builder.toString();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

	@Override
	public void stopClient() {
		// TODO Auto-generated method stub

	}

	private void notifyHandler(int notification) {
		if (handler != null) {
			handler.obtainMessage(notification, 0, 1).sendToTarget();
		}
	}

	@Override
	public boolean sendMessage(Object data) {
		// TODO Auto-generated method stub
		return false;
	}

}
