package poeschik.cashbag.tools;

import android.os.Handler;

public class DelayHandler extends Thread {
	
	/*
	 * creates a delay message
	 */
	
	public static final int N_DELAY = 100;
	
	private long trhreadDelay; 
	private Handler handler;
	
	public DelayHandler(long delay, Handler hdl) {
		trhreadDelay = delay;
		handler = hdl;
	}
	
	public void run() {
		try {
			Thread.sleep(trhreadDelay);
			handler.obtainMessage(N_DELAY, 0, 1).sendToTarget();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}

}
