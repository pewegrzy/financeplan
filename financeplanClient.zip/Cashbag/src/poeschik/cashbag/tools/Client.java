package poeschik.cashbag.tools;

import com.db4o.ObjectSet;

import poeschik.cashbag.messages.Amount;
import poeschik.cashbag.messages.Category;

public interface Client {
	
	/*
	 * interface for wifi and 3g extension
	 */
	
	public static final int N_CLIENT_ONLINE = 1;
	public static final int N_CLIENT_OFFLINE = 2;
	public static final int N_CLIENT_CONNECT = 3;
	public static final int N_CLIENT_PROGRESS = 4;
	
	public boolean sendMessage(Object data);
	public boolean sendMessage(ObjectSet<Amount> data);
	public boolean isConnected();
	public void run();
	public void stopClient();
	public Category[] receiveCategories();
	

}
