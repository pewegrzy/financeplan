package poeschik.cashbag.tools;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;

import com.db4o.ObjectSet;

import poeschik.cashbag.MainActivity;
import poeschik.cashbag.R;
import poeschik.cashbag.messages.ACK;
import poeschik.cashbag.messages.Amount;
import poeschik.cashbag.messages.Category;
import android.os.Handler;
import android.util.Log;


public class TCPClient implements Client {
	
	/*
	 * wifi extension but not used any more
	 */
	
	private static final String TAG = "TCP Client";
	 
    
    private static final String SERVERIP_INIT = "192.168.0.16"; //your computer IP address
    private static final int SERVERPORT_INIT = 59152;
    private static final int HEARTBEAT = 4000;
    
    private String serverIp = SERVERIP_INIT;
    private int serverPort = SERVERPORT_INIT;
    
    private Object serverMessage;
    private OnMessageReceived mMessageListener = null;
    private boolean mRun = false;
    private Handler handler = null;
    
    private Socket socket;
 
    ObjectOutputStream out;
    ObjectInputStream in;
 
    /**
     *  Constructor of the class. OnMessagedReceived listens for the messages received from server
     */
    public TCPClient(OnMessageReceived listener, Handler hdl) {
        mMessageListener = listener;
        handler = hdl;
    }
 
    /**
     * Sends the message entered by client to the server
     * @param message text entered by client
     */
    public boolean sendMessage(Object message){
        if (out != null) {
            try {
				out.writeObject(message);
				out.flush();
				return true;
			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}
            
        }
        return false;
    }
 
    public void stopClient() {
    	notifyHandler(N_CLIENT_OFFLINE);
        mRun = false;
    }
    
    private void startClient() {
    	mRun = true;
    }
 
    public void run() {
 
    	startClient();
 
        try {
            InetAddress serverAddr = InetAddress.getByName(serverIp);
 
            Log.i(TAG, "C: Connecting...");
            notifyHandler(N_CLIENT_CONNECT);
            socket = new Socket(serverAddr, serverPort);
 
            try {
 
                out = new ObjectOutputStream(socket.getOutputStream());
 
                Log.i(TAG, "C: Sent.");
 
                Log.i(TAG, "C: Done.");
                
                HeartBeat beat = new HeartBeat();
                beat.start();
  
                in = new ObjectInputStream(socket.getInputStream());
 
                notifyHandler(N_CLIENT_ONLINE);
                
                while (mRun) {
                    serverMessage = in.readObject();
 
                    if (serverMessage != null && mMessageListener != null) {
                        mMessageListener.messageReceived(serverMessage);
                    }
                    serverMessage = null;
                }
 
            } catch (Exception e) {
            	stopClient();
            	handlerMessage(R.string.m_tcp_client_server_closed_socket);
                Log.e(TAG, "S: Error", e); 
            } finally {
                socket.close();
                stopClient();
                Log.i(TAG, "socket closed");
            }
        } catch (Exception e) {
        	stopClient();
        	handlerMessage(R.string.m_tcp_client_timeout);
            Log.e(TAG, "C: Error", e); 
        }
    }
    
    public void closeSocket() {
    	try {
			socket.close();
			stopClient();
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    
    private class HeartBeat extends Thread {
    	public void run() {
    		while(mRun) {
    			try {
					Thread.sleep(HEARTBEAT);
					sendMessage(new ACK());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
    		}
    	}
    }
    
    
    private void notifyHandler(int notification) {
		if (handler != null) {
			handler.obtainMessage(notification, 0, 1).sendToTarget();
		}
	}
    
    private void handlerMessage(int message) {
		if (handler != null) {
			handler.obtainMessage(MainActivity.MESSAGE, message, 1)
					.sendToTarget();
		}
	}

    public interface OnMessageReceived {
        public void messageReceived(Object message);
    }


	@Override
	public boolean isConnected() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Category[] receiveCategories() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean sendMessage(ObjectSet<Amount> data) {
		// TODO Auto-generated method stub
		return false;
	}
}
