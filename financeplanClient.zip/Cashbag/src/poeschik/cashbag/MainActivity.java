package poeschik.cashbag;

import java.util.ArrayList;
import java.util.Calendar;

import poeschik.cashbag.db4o.Db4oHandler;
import poeschik.cashbag.fragment.Cashslot.OnSlotListener;
import poeschik.cashbag.fragment.Categories.OnCatListener;
import poeschik.cashbag.fragment.FragmentHandler;
import poeschik.cashbag.messages.Amount;
import poeschik.cashbag.messages.Category;
import poeschik.cashbag.tools.Client;
import poeschik.cashbag.tools.DelayHandler;
import poeschik.cashbag.tools.HttpClient;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.support.v4.view.ViewPager;
import android.view.Menu;
import android.widget.ArrayAdapter;
import android.widget.RadioButton;
import android.widget.TextView;

import com.db4o.ObjectSet;

public class MainActivity extends FragmentActivity implements OnCatListener,
		OnSlotListener {

	public static final int MESSAGE = 0;
	public static final String TAG = "Cashbag";

	private FragmentHandler fragmentHandler;
	private ViewPager viewPager;
	private Client client;
	private TextView Logger = null;
	private RadioButton stateOnline = null;
	private ArrayList<String> categories = new ArrayList<String>();
	private Db4oHandler db4ohandler = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// initialize layout elements
		Logger = (TextView) findViewById(R.id.textPagerLog);
		stateOnline = (RadioButton) findViewById(R.id.radioButtonOnline);

		fragmentHandler = new FragmentHandler(getBaseContext(),
				getSupportFragmentManager());

		viewPager = (ViewPager) findViewById(R.id.pager);
		viewPager.setAdapter(fragmentHandler);

		db4ohandler = Db4oHandler.getInstance(getBaseContext());

		// fill category spinner with values
		ObjectSet<? extends Object> check = db4ohandler.query(new Category());
		if (check instanceof ObjectSet) {
			@SuppressWarnings("unchecked")
			ObjectSet<Category> set = (ObjectSet<Category>) check;
			if (set != null && set.size() > 0) {
				for (Category cat : set) {
					categories.add(cat.getName());
				}
			}
		}

		// initialize http communication Handler
		client = new HttpClient(getBaseContext(), event_handler);

		// check internet connection and start synchronization process
		client.isConnected();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@SuppressLint("HandlerLeak")
	private final Handler event_handler = new Handler() {

		public void handleMessage(Message msg) {
			switch (msg.what) {

			case MESSAGE:
				Logger.setText(msg.arg1);
				new DelayHandler(5000, event_handler).start();
				break;

			case Client.N_CLIENT_ONLINE:
				Logger.setText("");
				stateOnline.setChecked(true);
				new CashbagTransaction().start();
				break;

			case Client.N_CLIENT_OFFLINE:
				stateOnline.setChecked(false);
				break;
				
			case Client.N_CLIENT_PROGRESS:
				Logger.setText("synch...");
				break;

			case DelayHandler.N_DELAY:
				Logger.setText("");
			}
		}
	};

	public void onApplyCategoryClick(String category) {
		// callback Categories fragment
		if (category.length() == 0) {
			handlerMessage(R.string.m_main_empty_cat);
			return;
		}
		addCategory(new Category(category, 0));
	}

	public void onApplySlotClick(String amount, String category) {
		// callback cash slot fragment
		double cash = checkAmount(amount);
		if (cash != 0) {
			Category cat = new Category();
			cat.setName(category);
			// get the object to the category string...
			ObjectSet<? extends Object> check = db4ohandler.queryByExample(cat);
			if (check instanceof ObjectSet) {
				@SuppressWarnings("unchecked")
				ObjectSet<Category> set = (ObjectSet<Category>) check;
				if (set != null && set.size() > 0) {
					// ... and save the new Amount
					db4ohandler.store(new Amount(getDate(), cash, set.get(0)));
				}
			}
		} else {
			handlerMessage(R.string.m_main_no_amount);
		}
	}

	private String getDate() {
		Calendar c = Calendar.getInstance();

		StringBuilder builder = new StringBuilder();
		builder.append(c.get(Calendar.YEAR) + "-");
		builder.append(c.get(Calendar.MONTH) + 1 + "-");
		builder.append(c.get(Calendar.DAY_OF_YEAR) + " ");
		builder.append(c.get(Calendar.HOUR_OF_DAY) + ":");
		builder.append(c.get(Calendar.MINUTE) + ":");
		builder.append(c.get(Calendar.SECOND));
		return builder.toString();
	}

	public ArrayAdapter<String> getCategoryList() {
		// callback cash slot fragment
		ArrayAdapter<String> aa = new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item, categories);
		aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		return aa;
	}

	private double checkAmount(String amount) {
		double sqlAmount = 0;
		try {
			sqlAmount = Double.parseDouble(amount);
		} catch (NumberFormatException e) {
			return sqlAmount;
		}
		return sqlAmount;
	}

	protected void onDestroy() {

		super.onDestroy();
		if (client != null) {
			client.stopClient();
		}
		if (db4ohandler != null) {
			db4ohandler.closeDb();
		}
	}

	private void handlerMessage(int message) {
		// helper for handler messaging
		if (event_handler != null) {
			event_handler.obtainMessage(MESSAGE, message, 1).sendToTarget();
		}
	}

	private class CashbagTransaction extends Thread {
		// synchronisation thread
		public void run() {
			sendCashbag();
		}
	}

	private void sendCashbag() {
		// get all amount entries
		ObjectSet<? extends Object> check = db4ohandler.query(new Amount(null,
				0, null));
		if (check instanceof ObjectSet) {
			@SuppressWarnings("unchecked")
			ObjectSet<Amount> set = (ObjectSet<Amount>) check;
			if (set != null && set.size() > 0) {
				// send all entries to the server
				client.sendMessage(set);
				for (Amount a : set) {
					// delete all entries in the local database
					db4ohandler.delete(a);
				}
			}
		}
		// delete all category entries
		check = db4ohandler.query(new Category());
		if (check instanceof ObjectSet) {
			@SuppressWarnings("unchecked")
			ObjectSet<Category> set = (ObjectSet<Category>) check;
			if (set != null && set.size() > 0) {
				for (Category c : set) {
					db4ohandler.delete(c);

				}
			}
		}
		// clear the spinner
		categories.clear();
		
		// synchronize categories with the server
		Category[] set = client.receiveCategories();
		if (set != null) {
			for (Category c : set) {
				addCategory(c);
			}
		}
	}

	private void addCategory(Category cat) {
		if (db4ohandler.store(cat)) {
			categories.add(cat.getName());
		} else {
			handlerMessage(R.string.m_main_existing_cat);
		}
	}
}
