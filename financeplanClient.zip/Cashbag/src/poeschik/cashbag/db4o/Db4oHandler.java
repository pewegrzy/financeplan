package poeschik.cashbag.db4o;

import android.content.Context;
import android.util.Log;

import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.constraints.UniqueFieldValueConstraintViolationException;

public class Db4oHandler extends Db4o_Service {
	
	/*
	 * special interface for financeplan application
	 */

	private static final String TAG = "Db4o Handler";
	private static Db4oHandler db4oHandler = null;

	public Db4oHandler(Context ctx) {
		super(ctx);
	}

	public static Db4oHandler getInstance(Context ctx) {
		if (db4oHandler == null) {
			db4oHandler = new Db4oHandler(ctx);
		}
		return db4oHandler;
	}

	public synchronized boolean store(Object value) {
		Log.d(TAG, "store " + value.getClass());
		ObjectContainer oc = openDb();
		if (oc != null) {
			try {
			oc.store(value);
			oc.commit();
			return true;
			} catch (UniqueFieldValueConstraintViolationException e) {
				e.printStackTrace();
				oc.rollback();
				return false;
			}
		}
		return false;
	}

	/*public synchronized void delete(Object value) {
		Object tmp = null;
		ObjectContainer oc = openDb();
		if (oc != null) {
			tmp = checkObject(value);
			ObjectSet<Object> result = oc.queryByExample(tmp);
			for (Object s : result) {
				oc.delete(s);
				oc.commit();
				Log.d(TAG, "delete Object " + s.getClass());
			}
		}
	}*/
	
	public synchronized void delete(Object value) {
		ObjectContainer oc = openDb();
		if (oc != null) {
			
			oc.delete(value);
			oc.commit();
			Log.d(TAG, "delete Object " + value.getClass());
			
		}
	}
	
	/*private Object checkObject(Object value) {
		if(value instanceof Amount) {
			Amount v = (Amount) value;
			return new Amount(v.getDate(), v.getValue(), v.getCategory());
		}
		return value;		
	}*/

	public synchronized ObjectSet<? extends Object> query(Object object) {
		ObjectContainer oc = openDb();
		if (oc != null) {
			return openDb().query(object.getClass());
		}
		return null;
	}
	
	public synchronized ObjectSet<? extends Object> queryByExample(Object object) {
		ObjectContainer oc = openDb();
		if (oc != null) {
			return openDb().queryByExample(object);
		}
		return null;
	}
}

