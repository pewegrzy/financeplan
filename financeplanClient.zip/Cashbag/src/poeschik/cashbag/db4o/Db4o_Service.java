package poeschik.cashbag.db4o;

import java.io.File;
import java.io.IOException;

import poeschik.cashbag.messages.Amount;
import poeschik.cashbag.messages.Category;
import android.content.Context;
import android.os.Environment;
import android.util.Log;

import com.db4o.Db4oEmbedded;
import com.db4o.ObjectContainer;
import com.db4o.config.EmbeddedConfiguration;
import com.db4o.constraints.UniqueFieldValueConstraint;

public class Db4o_Service {
	
	/*
	 * base functionality of the db4o database
	 */

	private static final String TAG = "Db4o_Service";
	private static final String DB_NAME = "Cashbag";

	private static ObjectContainer oc = null;
	private Context context;
	private String db_path;

	boolean externalStorageAvailable = false;
	boolean externalStorageWriteable = false;
	String storage_state = null;

	public Db4o_Service(Context ctx) {
		context = ctx;
		checkExternalStorage();
	}

	private void checkExternalStorage() {

		storage_state = Environment.getExternalStorageState();
		if (Environment.MEDIA_MOUNTED.equals(storage_state)) {
			// we can read and write the media
			externalStorageAvailable = externalStorageWriteable = true;
			db_path = context.getExternalFilesDir(null) + "/";
		} else if (Environment.MEDIA_MOUNTED_READ_ONLY.equals(storage_state)) {
			// we can only read the media
			externalStorageAvailable = true;
			externalStorageWriteable = false;
			db_path = context.getExternalFilesDir(null) + "/";
		} else {
			// something else is wrong. It may be one of many other states, but
			// all we need
			// to know is we can neither read nor write
			externalStorageAvailable = externalStorageWriteable = false;
			db_path = context.getDir("data", 0) + "/";
		}
	}

	public boolean isExternal() {
		if (externalStorageAvailable) {
			return true;
		}
		return false;
	}

	public ObjectContainer openDb() {

		try {
			if (oc == null || oc.ext().isClosed()) {
				Log.i(TAG, "open db4o -> " + DB_NAME);
				oc = Db4oEmbedded.openFile(dbConfig(), db4oDbFullPath());
			}
			return oc;
		} catch (Exception ie) {
			Log.e(TAG, ie.toString());
			return null;
		}
	}

	private EmbeddedConfiguration dbConfig() throws IOException {
		// object configuration in the database
		EmbeddedConfiguration configuration = Db4oEmbedded.newConfiguration();
		configuration.common().objectClass(Amount.class).cascadeOnUpdate(true);
		configuration.common().objectClass(Amount.class).cascadeOnActivate(true);
		configuration.common().objectClass(Category.class).objectField("name").indexed(true);
		configuration.common().add(new UniqueFieldValueConstraint(Category.class, "name"));
		return configuration;
	}

	public String db4oDbFullPath() {
		return db_path + DB_NAME + ".db4o";
	}

	public boolean deleteDb() {
		File db = new File(db4oDbFullPath());
		closeDb();
		Log.d(TAG, "delete " + db);
		return db.delete();
	}

	public void closeDb() {
		if (oc != null && !oc.ext().isClosed()) {
			Log.i(TAG, "close " + DB_NAME + ".db4o");
			oc.close();
		}
	}	
}
