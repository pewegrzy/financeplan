package poeschik.cashbag.messages;

import java.io.Serializable;

public class Amount implements Serializable {
	/*
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String date;
	private double value;
	private Category category;
	
	public Amount(String d, double v, Category c) {
		setDate(d);
		setValue(v);
		setCategory(c);
	}
	
	public String getDate() {
		return date;
	}
	private void setDate(String date) {
		this.date = date;
	}
	public double getValue() {
		return value;
	}
	private void setValue(double value) {
		this.value = value;
	}
	public Category getCategory() {
		return category;
	}
	private void setCategory(Category category) {
		this.category = category;
	}
}
