package poeschik.cashbag.messages;

import java.io.Serializable;

public class CategoryRequest implements Serializable{

	/* 
	 * request for wifi extension
	 */
	private static final long serialVersionUID = 1L;

}
