package poeschik.cashbag.messages;

import java.io.Serializable;

public class ACK implements Serializable {

	/*
	 * acknowledge message for wifi extension
	 */
	private static final long serialVersionUID = 1L;

}
