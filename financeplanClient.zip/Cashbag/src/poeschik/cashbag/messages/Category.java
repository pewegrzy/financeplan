package poeschik.cashbag.messages;

import java.io.Serializable;

public class Category implements Serializable {
	/*
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private int index;
	
	public Category(){
		
	}
	
	public Category(String n, int i) {
		setName(n);
		setIndex(i);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
}
