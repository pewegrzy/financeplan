package poeschik.cashbag.fragment;

import poeschik.cashbag.R;
import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

public class Cashslot extends Fragment implements OnClickListener {
	public static final String ARG_OBJECT = "object";
	
	private OnSlotListener listener;
	private View rootView;
	
	public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            listener = (OnSlotListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString());
        }
    }

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// the last two arguments ensure LayoutParams are inflated
		// properly.
		
		// initialize layout elements
		rootView = inflater.inflate(R.layout.view_cashslot, container,
				false);
		
		Button apply = (Button) rootView.findViewById(R.id.buttonSlotApplyPlus);
		apply.setOnClickListener(this);
		apply = (Button) rootView.findViewById(R.id.buttonSlotApplyMinus);
		apply.setOnClickListener(this);
		Spinner categories = (Spinner) rootView.findViewById(R.id.spinnerSlot);
		categories.setAdapter(listener.getCategoryList());
		return rootView;
	}
	
	private String getAmount() {
		EditText amount = (EditText) rootView.findViewById(R.id.editSlot);
		String tmp = amount.getText().toString();
		amount.setText("");
		return tmp;
	}
	
	private String getCategory() {
		Spinner categories = (Spinner) rootView.findViewById(R.id.spinnerSlot);
		
		return (String) categories.getSelectedItem();
	}
	
	public interface OnSlotListener {
        public void onApplySlotClick(String amount, String category);
        public ArrayAdapter<String> getCategoryList();
    }

	@Override
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.buttonSlotApplyPlus:	
			listener.onApplySlotClick(getAmount(), getCategory());
			break;
		case R.id.buttonSlotApplyMinus:
			listener.onApplySlotClick('-' + getAmount(), getCategory());
			break;
		}
		
	}
}