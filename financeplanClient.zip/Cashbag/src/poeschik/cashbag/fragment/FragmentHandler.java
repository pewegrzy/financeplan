package poeschik.cashbag.fragment;

import poeschik.cashbag.R;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

public class FragmentHandler extends FragmentStatePagerAdapter {
	
	/*
	 * provides fragment organisazion
	 */
	
	Context context;
	
	public FragmentHandler(Context ctx, FragmentManager fm) {
		super(fm);
		context = ctx;
	}

	@Override
	public Fragment getItem(int i) {
		Fragment fragment = new Fragment();
		Bundle args = new Bundle();;
		
		switch(i) {
		case 0:
			fragment = new Cashslot();	
			break;
						
		case 1:
			fragment = new Categories();	
			break;
			
		}
		fragment.setArguments(args);
		return fragment;
	}


	public int getCount() {
		return 2;
	}

	public CharSequence getPageTitle(int position) {
		// get page titles from res/values/strings
		String[] titles = context.getResources().getStringArray(R.array.titles);
		return titles[position];	
	}
}
