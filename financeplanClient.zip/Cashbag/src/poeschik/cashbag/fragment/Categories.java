package poeschik.cashbag.fragment;

import poeschik.cashbag.R;
import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

public class Categories extends Fragment implements OnClickListener {
	public static final String ARG_OBJECT = "object";
	
	private OnCatListener listener;
	private View rootView;
	
	public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            listener = (OnCatListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString());
        }
    }

	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		// the last two arguments ensure LayoutParams are inflated
		// properly.
		
		// initialize layout elements
		rootView = inflater.inflate(R.layout.view_categories, container,
				false);
		
		Button apply = (Button) rootView.findViewById(R.id.buttonCatApply);
		apply.setOnClickListener(this);
		
		return rootView;
	}
	
	private String getCategory() {
		EditText category = (EditText) rootView.findViewById(R.id.editCat);
		String tmp = category.getText().toString();
		category.setText("");
		return tmp;
	}
	
	public interface OnCatListener {
        public void onApplyCategoryClick(String category);
    }

	@Override
	public void onClick(View v) {
		switch(v.getId()) {
		case R.id.buttonCatApply:	
			listener.onApplyCategoryClick(getCategory().trim());
			break;
		}
		
	}
}
